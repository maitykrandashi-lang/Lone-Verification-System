import re
from collections import defaultdict

# Matches lines like:
# 12/06/2026  ATM WITHDRAWAL          2,500.00 DR   45,000.00
# 15-06-2026  SALARY CREDIT           55,000.00 CR   1,00,000.00
TRANSACTION_PATTERN = re.compile(
    r"(?P<date>\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4})"
    r".{0,60}?"
    r"(?P<amount>[\d,]+\.\d{2})\s*(?P<type>DR|CR|Dr|Cr|debit|credit)",
    re.IGNORECASE,
)

MONTH_PATTERN = re.compile(r"\d{1,2}[\/\-](?P<month>\d{1,2})[\/\-]\d{2,4}")


def _clean_amount(raw):
    try:
        return float(raw.replace(",", ""))
    except (ValueError, AttributeError):
        return 0.0


def parse_bank_statement(text):
    transactions = []
    for match in TRANSACTION_PATTERN.finditer(text):
        amount = _clean_amount(match.group("amount"))
        txn_type = match.group("type").upper()[0]  # 'D' or 'C'
        transactions.append({
            "date": match.group("date"),
            "amount": amount,
            "type": "Credit" if txn_type == "C" else "Debit",
        })

    # Aggregate credits vs debits by month (falls back to a single
    # "All transactions" bucket if no dates were confidently parsed)
    monthly = defaultdict(lambda: {"Credit": 0.0, "Debit": 0.0})

    for txn in transactions:
        month_match = MONTH_PATTERN.search(txn["date"])
        month_key = f"Month {month_match.group('month')}" if month_match else "Unknown"
        monthly[month_key][txn["type"]] += txn["amount"]

    labels = sorted(monthly.keys())
    credit_values = [monthly[m]["Credit"] for m in labels]
    debit_values = [monthly[m]["Debit"] for m in labels]

    total_credit = sum(t["amount"] for t in transactions if t["type"] == "Credit")
    total_debit = sum(t["amount"] for t in transactions if t["type"] == "Debit")

    if not labels:
        # nothing parsed with dates - still show total credit/debit as a bar chart
        labels = ["Total"]
        credit_values = [total_credit]
        debit_values = [total_debit]

    return {
        "transactions": transactions,
        "total_credit": total_credit,
        "total_debit": total_debit,
        "closing_estimate": total_credit - total_debit,
        "chart_data": {
            "labels": labels,
            "credit": credit_values,
            "debit": debit_values,
        },
        "found_any": len(transactions) > 0,
    }
